import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

import javax.swing.JTextField;

public class TimerThread extends Thread {

	private JTextField timerField;

	public TimerThread(JTextField timerField) {
		this.timerField = timerField;
	}

	public void run() {
		SimpleDateFormat format = new SimpleDateFormat("hh:mm:ss");
		try {
			while (true) {
				sleep(1000);
				timerField.setText("Текущее время: "
						+ format.format(GregorianCalendar.getInstance()
								.getTime()));
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
