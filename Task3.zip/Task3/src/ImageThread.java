import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class ImageThread extends Thread {

	private JPanel panel;
	private BufferedImage image;
	private int x, y;
	private BufferedImage bufer;
	private State state;

	public ImageThread(JPanel panel, BufferedImage image, int initX, int initY) {
		this.panel = panel;
		this.image = image;
		this.x = initX;
		this.y = initY;
		state = State.RUNNABLE;
		bufer = new BufferedImage(panel.getWidth(), panel.getHeight(),
				BufferedImage.TYPE_INT_RGB);
	}

	public void run() {
		try {
			int speedX = 5;
			int speedY = 5;
			while (true) {
				Thread.sleep(50);
				if (state.equals(State.WAITING))
					waitImageThread();
				synchronized (this) {
					x += speedX;
					y += speedY;
					if (x + image.getWidth() > panel.getWidth() || x < 0)
						speedX *= -1;
					if (y + image.getHeight() > panel.getHeight() || y < 0)
						speedY *= -1;
					paintImage();
				}
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized void waitImageThread() {
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public synchronized void notifyImageThread() {
		notify();
		state = State.RUNNABLE;
	}

	public void setStateToWaiting() {
		state = State.WAITING;
	}

	private void paintImage() {
		Graphics g = bufer.getGraphics();
		g.fillRect(0, 0, panel.getWidth(), panel.getHeight());
		g.drawImage(image, x, y, null);
		panel.getGraphics().drawImage(bufer, 0, 0, null);
	}

	private enum State {
		RUNNABLE, WAITING;
	}
}
