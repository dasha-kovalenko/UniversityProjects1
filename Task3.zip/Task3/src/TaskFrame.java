import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class TaskFrame extends JFrame {

	private JPanel imagePanel;
	private BufferedImage image;
	private JTextField timeField;
	private JButton ruleButton;
	private ImageThread imageThread;
	private TimerThread timerThread;

	public TaskFrame(String imagePath) {
		initComponents();
		initProperties();
		loadImage(imagePath);
		startThreads();
	}

	private void initComponents() {
		Container c = getContentPane();
		c.setLayout(new BorderLayout());

		imagePanel = new JPanel();

		JPanel timePanel = new JPanel();
		timePanel.setLayout(new GridLayout(1, 1));

		timeField = new JTextField();
		timeField.setEditable(false);

		timePanel.add(timeField);

		JPanel buttonPanel = new JPanel();
		buttonPanel.setLayout(new FlowLayout());

		ruleButton = new JButton("Пауза");

		buttonPanel.add(ruleButton);

		ruleButton.addActionListener(new RuleButtonListener());
		
		c.add(timePanel, BorderLayout.NORTH);
		c.add(imagePanel, BorderLayout.CENTER);
		c.add(buttonPanel, BorderLayout.SOUTH);
	}

	private void initProperties() {
		setTitle("task 3");
		setSize(640, 480);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}

	private void loadImage(String imagePath) {
		try {
			image = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void startThreads() {
		imageThread = new ImageThread(imagePanel, image, 0, 0);
		imageThread.setDaemon(true);
		imageThread.start();
		timerThread = new TimerThread(timeField);
		timerThread.setDaemon(true);
		timerThread.start();
	}

	public void paint(Graphics g) {

	}

	private class RuleButtonListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			JButton but = (JButton) e.getSource();
			if (but.equals(ruleButton)) {
				if (!imageThread.getState().equals(Thread.State.WAITING)) {
					imageThread.setStateToWaiting();
					ruleButton.setText("Возобновить");
				} else {
					imageThread.notifyImageThread();
					ruleButton.setText("Пауза");
				}
			}
		}
	}

}
