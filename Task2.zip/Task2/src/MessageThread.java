import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class MessageThread extends Thread {

	private JPanel panel;
	private int x, y;
	private String message;
	private Font font;
	private BufferedImage bufer;

	public MessageThread(JPanel panel, String message, Font font, int initX,
			int initY) {
		this.panel = panel;
		this.message = message;
		this.font = font;
		this.x = initX;
		this.y = initY;
		bufer = new BufferedImage(panel.getWidth(), panel.getHeight(),
				BufferedImage.TYPE_INT_RGB);
		bufer.getGraphics().setFont(font);
	}

	public void run() {
		try {
			int speedX = -5;
			while (true) {
				Thread.sleep(50);
				x += speedX;
				if (x + message.length() * font.getSize() < 0)
					x = panel.getWidth();
				paintImage();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void paintImage() {
		Graphics g = bufer.getGraphics();
		g.fillRect(0, 0, bufer.getWidth(), bufer.getHeight());
		g.setColor(new Color(0,0,0));
		g.drawString(message, x, y);
		panel.getGraphics().drawImage(bufer, 0, 0, null);
	}
}
