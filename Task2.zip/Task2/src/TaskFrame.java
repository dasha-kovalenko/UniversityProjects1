import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class TaskFrame extends JFrame {

	private JPanel stringPanel;

	public TaskFrame() {
		initComponents();
		initProperties();
		startThread();
	}

	private void initComponents() {
		Container c = getContentPane();
		c.setLayout(new BorderLayout());

		stringPanel = new JPanel();

		c.add(stringPanel, BorderLayout.CENTER);
	}

	private void initProperties() {
		setTitle("task 2");
		setSize(640, 480);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}

	private void startThread() {
		Font font = new Font("Arial", Font.BOLD, 15);
		MessageThread th = new MessageThread(stringPanel,
				"Hello! Hello! Hello! Hello! Hello!", font,
				stringPanel.getWidth(), stringPanel.getHeight() / 2);
		th.setDaemon(true);
		th.start();
	}

	public void paint(Graphics g) {

	}

}
