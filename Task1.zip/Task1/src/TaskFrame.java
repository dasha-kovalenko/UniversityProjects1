import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class TaskFrame extends JFrame {

	private JPanel imagePanel;
	private BufferedImage image;

	public TaskFrame(String imagePath) {
		initComponents();
		initProperties();
		loadImage(imagePath);
		startThread();
	}

	private void initComponents() {
		Container c = getContentPane();
		c.setLayout(new BorderLayout());

		imagePanel = new JPanel();

		c.add(imagePanel, BorderLayout.CENTER);
	}

	private void initProperties() {
		setTitle("task 1");
		setSize(640, 480);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setVisible(true);
		setResizable(false);
	}

	private void loadImage(String imagePath) {
		try {
			image = ImageIO.read(new File(imagePath));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void startThread() {
		ImageThread th = new ImageThread(imagePanel, image, 0, 0);
		th.setDaemon(true);
		th.start();
	}

	public void paint(Graphics g) {

	}

}
