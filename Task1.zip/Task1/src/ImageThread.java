import java.awt.Graphics;
import java.awt.image.BufferedImage;

import javax.swing.JPanel;

public class ImageThread extends Thread {

	private JPanel panel;
	private BufferedImage image;
	private int x, y;
	private BufferedImage bufer;

	public ImageThread(JPanel panel, BufferedImage image, int initX, int initY) {
		this.panel = panel;
		this.image = image;
		this.x = initX;
		this.y = initY;
		bufer = new BufferedImage(panel.getWidth(), panel.getHeight(),
				BufferedImage.TYPE_INT_RGB);
	}

	public void run() {
		try {
			int speedX = 5;
			int speedY = 5;
			while (true) {
				Thread.sleep(50);
				x += speedX;
				y += speedY;
				if (x + image.getWidth() > panel.getWidth() || x < 0)
					speedX *= -1;
				if (y + image.getHeight() > panel.getHeight() || y < 0)
					speedY *= -1;
				paintImage();
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void paintImage() {
		Graphics g = bufer.getGraphics();
		g.fillRect(0, 0, bufer.getWidth(), bufer.getHeight());
		g.drawImage(image, x, y, null);
		panel.getGraphics().drawImage(bufer, 0, 0, null);
	}
}
